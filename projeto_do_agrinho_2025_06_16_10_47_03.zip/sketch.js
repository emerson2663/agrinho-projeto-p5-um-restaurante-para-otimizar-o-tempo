let pessoas = [];
let restaurante;
let arvores = []; // Array para armazenar as árvores

function setup() {
  createCanvas(900, 600); // Tela maior para mais detalhes

  // Cria o restaurante
  restaurante = new Restaurante(300, 250, 250, 150, color(180, 100, 50), color(139, 69, 19), color(255, 255, 220), "Sabor do Sul");

  // Cria algumas pessoas
  for (let i = 0; i < 4; i++) {
    // Pessoas começam em posições aleatórias na estrada
    pessoas.push(new Pessoa(random(width), 450));
  }

  // Cria algumas árvores em posições estratégicas
  arvores.push(new Arvore(200, 320, 100)); // Árvore à esquerda do restaurante
  arvores.push(new Arvore(600, 320, 120)); // Árvore à direita do restaurante, um pouco maior
  arvores.push(new Arvore(80, 400, 80)); // Árvore mais próxima da estrada
  arvores.push(new Arvore(750, 400, 90)); // Outra árvore próxima à estrada
}

function draw() {
  // Céu azul
  background(135, 206, 235);

  // Sol
  fill(255, 255, 0);
  noStroke();
  ellipse(width - 80, 80, 100, 100);

  // Nuvens
  fill(255);
  ellipse(150, 70, 120, 60);
  ellipse(180, 90, 100, 50);
  ellipse(600, 100, 150, 70);
  ellipse(650, 120, 100, 50);

  // Chão rural (grama)
  fill(80, 180, 60);
  rect(0, 300, width, height); // Cobrindo a tela toda antes da estrada

  // Estrada de terra
  fill(139, 69, 19, 180); // Marrom, levemente transparente
  rect(0, height * 0.7, width, height * 0.3); // Começa em 70% da altura

  // Linha da estrada (opcional, para dar mais profundidade)
  stroke(100);
  strokeWeight(2);
  line(0, height * 0.7 + 5, width, height * 0.7 + 5);
  line(0, height * 0.7 + 10, width, height * 0.7 + 10);
  noStroke(); // Remove a linha para os outros elementos

  // Desenha as árvores primeiro para que fiquem atrás do restaurante e das pessoas
  for (let arvore of arvores) {
    arvore.display();
  }

  // Desenha o restaurante
  restaurante.display();

  // Desenha e move as pessoas
  for (let pessoa of pessoas) {
    pessoa.display();
    pessoa.andar();
  }
}

// --- Classe para o Restaurante ---
class Restaurante {
  constructor(x, y, w, h, bodyColor, roofColor, signColor, signText) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.bodyColor = bodyColor;
    this.roofColor = roofColor;
    this.signColor = signColor;
    this.signText = signText;
  }

  display() {
    // Corpo do restaurante
    fill(this.bodyColor);
    rect(this.x, this.y, this.w, this.h);

    // Telhado
    fill(this.roofColor);
    triangle(this.x, this.y,
             this.x + this.w / 2, this.y - this.h / 2,
             this.x + this.w, this.y);

    // Porta
    fill(100, 50, 0);
    rect(this.x + this.w * 0.4, this.y + this.h * 0.6, this.w * 0.2, this.h * 0.4);

    // Janelas
    fill(173, 216, 230); // Azul claro para a janela
    rect(this.x + this.w * 0.1, this.y + this.h * 0.3, this.w * 0.2, this.h * 0.3);
    rect(this.x + this.w * 0.7, this.y + this.h * 0.3, this.w * 0.2, this.h * 0.3);


    // Placa do restaurante
    fill(this.signColor);
    rect(this.x + this.w / 4, this.y - this.h / 4, this.w / 2, this.h / 4); // Posição acima do telhado

    fill(0); // Cor do texto
    textSize(24);
    textAlign(CENTER, CENTER);
    text(this.signText, this.x + this.w / 2, this.y - this.h / 4 + (this.h / 8));
  }
}

// --- Classe para a Pessoa ---
class Pessoa {
  constructor(x, y) {
    this.x = x;
    this.y = y; // Posição Y fixa na estrada
    this.tamanhoCorpo = 30;
    this.tamanhoCabeca = 15;
    this.velocidade = random(1, 2); // Velocidade aleatória para cada pessoa
    this.direcao = random([-1, 1]); // -1 para esquerda, 1 para direita
    this.pernaOffset = 0; // Para animação de pernas
    this.pernaVelocidade = 0.1; // Velocidade da animação da perna
  }

  display() {
    push(); // Salva as configurações de desenho atuais
    translate(this.x, this.y); // Move a origem para a posição da pessoa

    // Corpo
    fill(0); // Cor da roupa (preto)
    rectMode(CENTER);
    rect(0, 0, this.tamanhoCorpo * 0.7, this.tamanhoCorpo);

    // Cabeça
    fill(255, 220, 180); // Cor da pele
    ellipse(0, -this.tamanhoCorpo / 2 - this.tamanhoCabeca / 2, this.tamanhoCabeca, this.tamanhoCabeca);

    // Pernas (simples, com movimento)
    fill(50); // Cor da calça
    rect(-this.tamanhoCorpo * 0.15, this.tamanhoCorpo / 2 + sin(this.pernaOffset) * 5, this.tamanhoCorpo * 0.3, this.tamanhoCorpo * 0.7);
    rect(this.tamanhoCorpo * 0.15, this.tamanhoCorpo / 2 - sin(this.pernaOffset) * 5, this.tamanhoCorpo * 0.3, this.tamanhoCorpo * 0.7);

    pop(); // Restaura as configurações de desenho
  }

  andar() {
    this.x += this.velocidade * this.direcao;
    this.pernaOffset += this.pernaVelocidade; // Atualiza o offset da perna

    // Reinicia a posição da pessoa se ela sair da tela
    if (this.x > width + 50 || this.x < -50) {
      this.x = (this.direcao === 1) ? -50 : width + 50; // Aparece do outro lado
      this.y = 450; // Garante que esteja na estrada
    }
  }
}

// --- Nova Classe para a Árvore ---
class Arvore {
  constructor(x, y, tamanho) {
    this.x = x;
    this.y = y;
    this.tamanho = tamanho; // Controla o tamanho geral da árvore
    this.alturaTronco = this.tamanho * 0.7;
    this.larguraTronco = this.tamanho * 0.15;
    this.raioCopa = this.tamanho * 0.4;
  }

  display() {
    // Tronco da árvore
    fill(100, 50, 0); // Cor marrom
    rect(this.x - this.larguraTronco / 2, this.y - this.alturaTronco, this.larguraTronco, this.alturaTronco);

    // Copa da árvore (círculos para dar volume)
    fill(34, 139, 34); // Cor verde-floresta
    ellipse(this.x, this.y - this.alturaTronco - this.raioCopa * 0.6, this.raioCopa * 1.8, this.raioCopa * 1.8);
    ellipse(this.x - this.raioCopa * 0.5, this.y - this.alturaTronco - this.raioCopa * 0.2, this.raioCopa * 1.2, this.raioCopa * 1.2);
    ellipse(this.x + this.raioCopa * 0.5, this.y - this.alturaTronco - this.raioCopa * 0.2, this.raioCopa * 1.2, this.raioCopa * 1.2);
  }
}